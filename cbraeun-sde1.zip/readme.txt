Collin Braeuning, cbraeun
ECE 3520 SDE1
March 2018

On my honor I have neither given nor received aid on this exam
COLLIN BRAEUNING

This project explores prolog and CYK parse tables.

FILES INCLUDED:
	sde1.pro
		Includes all predicates needed to test this project.
		Manipulates lists in order to create the bottom row of a CYK parse table
		Reads production tables to form cells and rows.

	sde1.log
		Shows at least 3 test cases for each of the predicates required.